package dk.steven.scangas.mcts2048.measure;

import dk.steven.scangas.mcts2048.Board;

public interface Measure {
	double score(Board board);
}
