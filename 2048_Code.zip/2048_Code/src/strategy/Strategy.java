package dk.steven.scangas.mcts2048.strategy;

import dk.steven.scangas.mcts2048.Board;

public interface Strategy {
	public Board play(Board board);
}
